package starter.ui.registration;

import net.serenitybdd.annotations.DefaultUrl;
import net.thucydides.core.pages.PageObject;

@DefaultUrl("http://127.0.0.1:5500")
public class RegisterPage extends PageObject {
}
